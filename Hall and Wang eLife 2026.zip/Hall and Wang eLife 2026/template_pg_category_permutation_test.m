function Results = template_pg_category_permutation_test(Data, params)
% TEMPLATE_PG_CATEGORY_PERMUTATION_TEST
%
% Generalized prediction-gain category preservation / ensemble turnover
% analysis. This is a publication-facing template stripped of project paths.
%
% Required Data columns:
%   NeuronID   unique neuron identifier
%   Group      optional neuron group label, e.g. "All", "Group1", "Group2"
%   PrePG      pre-training prediction gain
%   PostPG     post-training prediction gain
%
% Optional Data columns:
%   AnimalID   animal identifier for later plotting/reporting
%
% Required params fields:
%   nPerm      number of label-shuffle permutations, e.g. 10000
%
% Output:
%   Results.TransitionMatrix
%   Results.TransitionStats
%   Results.ShuffledTransitionMatrix
%   Results.RankCorrelation

arguments
    Data table
    params.nPerm double = 10000
end

if ~ismember('Group', Data.Properties.VariableNames)
    Data.Group = repmat("NeuronGroup1", height(Data), 1);
end

groups = unique(string(Data.Group), 'stable');
TransitionMatrix = table();
TransitionStats = table();
ShuffledTransitionMatrix = table();
RankCorrelation = table();

for g = groups(:)'
    T = Data(string(Data.Group) == g & isfinite(Data.PrePG) & isfinite(Data.PostPG), :);
    RankCorrelation = [RankCorrelation; rankCorrStats(T, g)]; %#ok<AGROW>
    [M, S] = transitionStats(T, g, params.nPerm);
    TransitionMatrix = [TransitionMatrix; M]; %#ok<AGROW>
    TransitionStats = [TransitionStats; S]; %#ok<AGROW>
    ShuffledTransitionMatrix = [ShuffledTransitionMatrix; shuffledTransitionMatrix(T, g, params.nPerm)]; %#ok<AGROW>
end

Results = struct();
Results.TransitionMatrix = TransitionMatrix;
Results.TransitionStats = TransitionStats;
Results.ShuffledTransitionMatrix = ShuffledTransitionMatrix;
Results.RankCorrelation = RankCorrelation;
end

function C = rankCorrStats(T, groupName)
[rhoS, pS] = corr(T.PrePG, T.PostPG, 'Type','Spearman', 'Rows','complete');
[rhoP, pP] = corr(T.PrePG, T.PostPG, 'Type','Pearson', 'Rows','complete');
preRank = tiedrank(T.PrePG);
postRank = tiedrank(T.PostPG);
[rhoRank, pRank] = corr(preRank, postRank, 'Type','Pearson', 'Rows','complete');
C = table(string(groupName), height(T), rhoS, pS, rhoP, pP, rhoRank, pRank, ...
    'VariableNames', {'Group','N','SpearmanRho_PrePG_PostPG','SpearmanP','PearsonR_PrePG_PostPG','PearsonP', ...
    'PearsonR_PreRank_PostRank','PearsonRankP'});
end

function [Tmat, S] = transitionStats(T, groupName, nPerm)
preCat = quartileCategory(T.PrePG);
postCat = quartileCategory(T.PostPG);
cats = ["Bottom25","Middle50","Top25"];

rows = cell(0, 7);
for i = 1:numel(cats)
    from = cats(i);
    idx = preCat == from;
    denom = sum(idx);
    for j = 1:numel(cats)
        to = cats(j);
        count = sum(idx & postCat == to);
        rows(end+1,:) = {string(groupName), from, to, count, denom, count ./ max(denom,1), height(T)}; %#ok<AGROW>
    end
end
Tmat = cell2table(rows, 'VariableNames', {'Group','PreCategory','PostCategory','Count','PreCategoryN','Fraction','TotalN'});

obsTopRetain = sum(preCat=="Top25" & postCat=="Top25");
obsBottomRetain = sum(preCat=="Bottom25" & postCat=="Bottom25");
obsExtremeSwitch = sum(preCat=="Top25" & postCat=="Bottom25") + sum(preCat=="Bottom25" & postCat=="Top25");
[pTop, pBottom, pSwitch] = permutationTransitionP(preCat, postCat, obsTopRetain, obsBottomRetain, obsExtremeSwitch, nPerm);

S = table(string(groupName), height(T), sum(preCat=="Top25"), sum(preCat=="Bottom25"), ...
    obsTopRetain, obsBottomRetain, obsExtremeSwitch, ...
    obsTopRetain ./ max(sum(preCat=="Top25"),1), obsBottomRetain ./ max(sum(preCat=="Bottom25"),1), ...
    obsExtremeSwitch ./ max(sum(preCat=="Top25" | preCat=="Bottom25"),1), pTop, pBottom, pSwitch, nPerm, ...
    'VariableNames', {'Group','N','PreTop25N','PreBottom25N','Top25RetainedN','Bottom25RetainedN', ...
    'ExtremeSwitchN','Top25RetainedFraction','Bottom25RetainedFraction','ExtremeSwitchFraction', ...
    'PermutationP_TopRetentionGreaterChance','PermutationP_BottomRetentionGreaterChance', ...
    'PermutationP_ExtremeSwitchGreaterChance','NPermutations'});
end

function S = shuffledTransitionMatrix(T, groupName, nPerm)
preCat = quartileCategory(T.PrePG);
postCat = quartileCategory(T.PostPG);
cats = ["Bottom25","Middle50","Top25"];
accum = zeros(3,3);
for p = 1:nPerm
    shuffled = postCat(randperm(numel(postCat)));
    for i = 1:3
        denom = sum(preCat == cats(i));
        for j = 1:3
            accum(i,j) = accum(i,j) + sum(preCat == cats(i) & shuffled == cats(j)) ./ max(denom, 1);
        end
    end
end
meanFrac = accum ./ nPerm;
rows = cell(0, 5);
for i = 1:3
    for j = 1:3
        rows(end+1,:) = {string(groupName), cats(i), cats(j), meanFrac(i,j), nPerm}; %#ok<AGROW>
    end
end
S = cell2table(rows, 'VariableNames', {'Group','PreCategory','PostCategory','ShuffleMeanFraction','NPermutations'});
end

function cats = quartileCategory(x)
cats = repmat("Middle50", numel(x), 1);
q = quantile(x, [0.25 0.75]);
cats(x <= q(1)) = "Bottom25";
cats(x >= q(2)) = "Top25";
end

function [pTop, pBottom, pSwitch] = permutationTransitionP(preCat, postCat, obsTop, obsBottom, obsSwitch, nPerm)
topNull = zeros(nPerm,1);
bottomNull = zeros(nPerm,1);
switchNull = zeros(nPerm,1);
for p = 1:nPerm
    shuffled = postCat(randperm(numel(postCat)));
    topNull(p) = sum(preCat=="Top25" & shuffled=="Top25");
    bottomNull(p) = sum(preCat=="Bottom25" & shuffled=="Bottom25");
    switchNull(p) = sum(preCat=="Top25" & shuffled=="Bottom25") + sum(preCat=="Bottom25" & shuffled=="Top25");
end
pTop = (sum(topNull >= obsTop) + 1) / (nPerm + 1);
pBottom = (sum(bottomNull >= obsBottom) + 1) / (nPerm + 1);
pSwitch = (sum(switchNull >= obsSwitch) + 1) / (nPerm + 1);
end
