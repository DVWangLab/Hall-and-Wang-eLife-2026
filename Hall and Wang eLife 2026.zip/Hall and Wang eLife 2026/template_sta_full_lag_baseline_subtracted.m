function Results = template_sta_full_lag_baseline_subtracted(SpikeTable, UnitTable, EpochTable, params)
% TEMPLATE_STA_FULL_LAG_BASELINE_SUBTRACTED
%
% Generalized ACC-triggered target-neuron spike-triggered average (STA)
% analysis with baseline subtraction and full-lag significance testing.
%
% This template removes all project-specific file loading. Before calling,
% prepare generic tables with the fields below.
%
% Required SpikeTable columns:
%   UnitID      string/categorical neuron identifier
%   Region      string/categorical region label, e.g. "TriggerRegion" or "TargetRegion"
%   SpikeTime   spike timestamps in seconds
%   AnimalID    animal/session grouping identifier
%   Session     repeated-measure label, e.g. "Pre" or "Post"
%
% Required UnitTable columns:
%   UnitID      target neuron identifier
%   Group       neuron group label, e.g. "NeuronGroup1", "NeuronGroup2"
%   AnimalID
%
% Required EpochTable columns:
%   AnimalID
%   Session
%   EpochLabel  e.g. "AnalysisEpoch"
%   StartTime
%   EndTime
%
% Required params fields:
%   triggerRegion      e.g. "ACC"
%   targetRegion       e.g. "CA1"
%   epochLabel         e.g. "SWS"
%   edges              lag bin edges in seconds, e.g. -0.2:0.01:0.3
%   baselineWindow     e.g. [-0.2 -0.1]
%   nPerm              e.g. 5000
%
% Output:
%   Results.CurveTable       per-neuron/session baseline-subtracted lag curves
%   Results.CurveSummary     group/session mean +/- SEM lag curves
%   Results.FullLagNeuron    bin-wise matched-neuron Pre/Post tests
%   Results.FullLagAnimal    bin-wise animal-mean Pre/Post tests
%   Results.ClusterStats     animal-level sign-flip cluster permutation results

arguments
    SpikeTable table
    UnitTable table
    EpochTable table
    params.triggerRegion string = "TriggerRegion"
    params.targetRegion string = "TargetRegion"
    params.epochLabel string = "AnalysisEpoch"
    params.edges double = -0.2:0.01:0.3
    params.baselineWindow double = [-0.2 -0.1]
    params.nPerm double = 5000
end

params.centers = params.edges(1:end-1) + diff(params.edges(1:2))/2;
params.binWidth = diff(params.edges(1:2));

CurveTable = buildStaCurves(SpikeTable, UnitTable, EpochTable, params);
CurveSummary = summarizeCurves(CurveTable);
[FullLagNeuron, FullLagAnimal, ClusterStats] = fullLagStats(CurveTable, params.nPerm);

Results = struct();
Results.CurveTable = CurveTable;
Results.CurveSummary = CurveSummary;
Results.FullLagNeuron = FullLagNeuron;
Results.FullLagAnimal = FullLagAnimal;
Results.ClusterStats = ClusterStats;
end

function C = buildStaCurves(SpikeTable, UnitTable, EpochTable, params)
C = table();
animals = unique(string(SpikeTable.AnimalID), 'stable');
sessions = unique(string(SpikeTable.Session), 'stable');

for a = 1:numel(animals)
    for s = 1:numel(sessions)
        animalID = animals(a);
        sessionName = sessions(s);

        epochRows = EpochTable(string(EpochTable.AnimalID) == animalID & ...
            string(EpochTable.Session) == sessionName & string(EpochTable.EpochLabel) == params.epochLabel, :);
        if isempty(epochRows)
            continue
        end

        sessionSpikes = SpikeTable(string(SpikeTable.AnimalID) == animalID & string(SpikeTable.Session) == sessionName, :);
        triggerSpikes = sessionSpikes.SpikeTime(string(sessionSpikes.Region) == params.triggerRegion);
        triggerSpikes = filterToIntervals(triggerSpikes, epochRows.StartTime, epochRows.EndTime, params.edges(1), params.edges(end));
        triggerSpikes = sort(triggerSpikes(isfinite(triggerSpikes)));
        if isempty(triggerSpikes)
            continue
        end

        targetUnits = UnitTable(string(UnitTable.AnimalID) == animalID, :);
        for u = 1:height(targetUnits)
            unitID = string(targetUnits.UnitID(u));
            targetSpikes = sessionSpikes.SpikeTime(string(sessionSpikes.UnitID) == unitID & string(sessionSpikes.Region) == params.targetRegion);
            targetSpikes = filterToIntervals(targetSpikes, epochRows.StartTime, epochRows.EndTime, 0, 0);
            targetSpikes = sort(targetSpikes(isfinite(targetSpikes)));
            if isempty(targetSpikes)
                continue
            end

            rawRates = triggeredRates(targetSpikes, triggerSpikes, params.edges, params.binWidth);
            base = mean(rawRates(params.centers >= params.baselineWindow(1) & params.centers < params.baselineWindow(2)), 'omitnan');
            normRates = rawRates - base;
            for b = 1:numel(params.centers)
                C = [C; table(animalID, sessionName, unitID, string(targetUnits.Group(u)), ...
                    params.centers(b), rawRates(b), base, normRates(b), ...
                    'VariableNames', {'AnimalID','Session','UnitID','Group','LagSeconds','RawRateHz','BaselineRateHz','NormRateHz'})]; %#ok<AGROW>
            end
        end
    end
end
end

function rates = triggeredRates(targetSpikes, triggerSpikes, edges, binWidth)
targetSpikes = sort(targetSpikes(:));
triggerSpikes = sort(triggerSpikes(:));
counts = zeros(1, numel(edges)-1);
if isempty(targetSpikes) || isempty(triggerSpikes)
    rates = nan(size(counts));
    return
end

minLag = edges(1);
maxLag = edges(end);
left = 1;
right = 0;
lags = [];
for i = 1:numel(targetSpikes)
    t = targetSpikes(i);
    while left <= numel(triggerSpikes) && triggerSpikes(left) < t - maxLag
        left = left + 1;
    end
    if right < left - 1
        right = left - 1;
    end
    while right < numel(triggerSpikes) && triggerSpikes(right + 1) <= t - minLag
        right = right + 1;
    end
    if right >= left
        lags = [lags; t - triggerSpikes(left:right)]; %#ok<AGROW>
    end
end
if ~isempty(lags)
    counts = histcounts(lags, edges);
end
rates = counts ./ (numel(triggerSpikes) * binWidth);
end

function y = filterToIntervals(x, starts, ends, prePad, postPad)
x = x(isfinite(x));
keep = false(size(x));
for i = 1:numel(starts)
    keep = keep | (x >= starts(i) - prePad & x <= ends(i) - postPad);
end
y = x(keep);
end

function S = summarizeCurves(C)
[G, group, session, lag] = findgroups(string(C.Group), string(C.Session), C.LagSeconds);
n = splitapply(@numel, C.NormRateHz, G);
mu = splitapply(@mean, C.NormRateHz, G);
sd = splitapply(@std, C.NormRateHz, G);
S = table(group, session, lag, n, mu, sd ./ sqrt(n), ...
    'VariableNames', {'Group','Session','LagSeconds','N','MeanNormRateHz','SEMNormRateHz'});
end

function [NeuronStats, AnimalStats, ClusterStats] = fullLagStats(C, nPerm)
groups = unique(string(C.Group), 'stable');
NeuronStats = table();
AnimalStats = table();
ClusterStats = table();
for g = groups(:)'
    G = C(string(C.Group) == g, :);
    NeuronStats = [NeuronStats; binwisePairedStats(G, "UnitID", g, "Neuron")]; %#ok<AGROW>
    A = animalMeanCurves(G);
    AnimalStats = [AnimalStats; binwisePairedStats(A, "AnimalID", g, "Animal")]; %#ok<AGROW>
    ClusterStats = [ClusterStats; clusterPermutation(A, g, nPerm)]; %#ok<AGROW>
end
end

function A = animalMeanCurves(G)
[grp, animal, session, lag] = findgroups(string(G.AnimalID), string(G.Session), G.LagSeconds);
y = splitapply(@mean, G.NormRateHz, grp);
A = table(animal, session, lag, y, 'VariableNames', {'AnimalID','Session','LagSeconds','NormRateHz'});
end

function S = binwisePairedStats(G, keyVar, groupName, levelName)
lags = sort(unique(G.LagSeconds));
rows = cell(numel(lags), 12);
pRaw = nan(numel(lags), 1);
for i = 1:numel(lags)
    L = G(G.LagSeconds == lags(i), :);
    pre = L(string(L.Session) == "Pre", {char(keyVar),'NormRateHz'});
    post = L(string(L.Session) == "Post", {char(keyVar),'NormRateHz'});
    pre.Properties.VariableNames{'NormRateHz'} = 'PreRateHz';
    post.Properties.VariableNames{'NormRateHz'} = 'PostRateHz';
    J = innerjoin(pre, post, 'Keys', char(keyVar));
    d = J.PostRateHz - J.PreRateHz;
    [p, t] = pairedT(d);
    pRaw(i) = p;
    rows(i,:) = {string(groupName), string(levelName), lags(i), height(J), ...
        mean(J.PreRateHz,'omitnan'), mean(J.PostRateHz,'omitnan'), mean(d,'omitnan'), ...
        median(d,'omitnan'), std(d,'omitnan'), t, p, signrankOrNan(d)};
end
q = bhFdr(pRaw);
S = cell2table(rows, 'VariableNames', {'Group','Level','LagSeconds','NMatched','MeanPreRateHz','MeanPostRateHz', ...
    'MeanDeltaPostMinusPreHz','MedianDeltaPostMinusPreHz','SDDeltaPostMinusPreHz','TStat','P_paired_ttest','P_signrank'});
S.Q_FDR_paired_ttest = q;
S.SignificantFDR05 = q < 0.05;
end

function C = clusterPermutation(A, groupName, nPerm)
lags = sort(unique(A.LagSeconds));
preWide = rateWide(A, "Pre", lags);
postWide = rateWide(A, "Post", lags);
[animals, ia, ib] = intersect(preWide.AnimalID, postWide.AnimalID, 'stable');
if numel(animals) < 3
    C = emptyClusterRow(groupName, numel(animals));
    return
end
D = postWide.Rate(ib,:) - preWide.Rate(ia,:);
[tObs, pObs] = pairedTByColumn(D);
clusters = findClusters(pObs < 0.05 & isfinite(tObs), tObs);
if isempty(clusters)
    C = emptyClusterRow(groupName, numel(animals));
    return
end
maxMass = zeros(nPerm, 1);
for p = 1:nPerm
    signs = (randi([0 1], size(D,1), 1) * 2 - 1);
    [tPerm, pPerm] = pairedTByColumn(D .* signs);
    cl = findClusters(pPerm < 0.05 & isfinite(tPerm), tPerm);
    if isempty(cl)
        maxMass(p) = 0;
    else
        maxMass(p) = max(abs([cl.Mass]));
    end
end
rows = cell(numel(clusters), 8);
for i = 1:numel(clusters)
    pCluster = (1 + sum(maxMass >= abs(clusters(i).Mass))) / (nPerm + 1);
    rows(i,:) = {string(groupName), i, lags(clusters(i).StartIdx), lags(clusters(i).EndIdx), ...
        clusters(i).Mass, clusters(i).Sign, pCluster, numel(animals)};
end
C = cell2table(rows, 'VariableNames', {'Group','ClusterIndex','StartLagSeconds','EndLagSeconds','ClusterMass','ClusterSign','PCluster','NAnimals'});
end

function W = rateWide(A, sessionName, lags)
S = A(string(A.Session) == sessionName, :);
animals = unique(string(S.AnimalID), 'stable');
R = nan(numel(animals), numel(lags));
for i = 1:numel(animals)
    for j = 1:numel(lags)
        v = S.NormRateHz(string(S.AnimalID) == animals(i) & S.LagSeconds == lags(j));
        if ~isempty(v)
            R(i,j) = v(1);
        end
    end
end
W = table(animals, R, 'VariableNames', {'AnimalID','Rate'});
end

function [t, p] = pairedTByColumn(D)
t = nan(1, size(D,2)); p = nan(1, size(D,2));
for j = 1:size(D,2)
    d = D(:,j); d = d(isfinite(d));
    if numel(d) >= 3
        [~, p(j), ~, st] = ttest(d);
        t(j) = st.tstat;
    end
end
end

function clusters = findClusters(sig, tVals)
clusters = struct('StartIdx', {}, 'EndIdx', {}, 'Mass', {}, 'Sign', {});
sig = sig(:)'; tVals = tVals(:)';
i = 1;
while i <= numel(sig)
    if ~sig(i)
        i = i + 1; continue
    end
    sgn = sign(tVals(i));
    j = i;
    while j + 1 <= numel(sig) && sig(j+1) && sign(tVals(j+1)) == sgn
        j = j + 1;
    end
    idx = i:j;
    clusters(end+1).StartIdx = i; %#ok<AGROW>
    clusters(end).EndIdx = j;
    clusters(end).Mass = sum(tVals(idx));
    clusters(end).Sign = sgn;
    i = j + 1;
end
end

function C = emptyClusterRow(groupName, nAnimals)
C = table(string(groupName), 0, NaN, NaN, NaN, NaN, NaN, nAnimals, ...
    'VariableNames', {'Group','ClusterIndex','StartLagSeconds','EndLagSeconds','ClusterMass','ClusterSign','PCluster','NAnimals'});
end

function [p, t] = pairedT(d)
d = d(isfinite(d));
if numel(d) < 2
    p = NaN; t = NaN; return
end
[~, p, ~, st] = ttest(d);
t = st.tstat;
end

function p = signrankOrNan(d)
d = d(isfinite(d));
if numel(d) < 2
    p = NaN;
else
    p = signrank(d);
end
end

function q = bhFdr(p)
p = p(:); valid = isfinite(p); q = nan(size(p));
if ~any(valid); return; end
[ps, order] = sort(p(valid));
m = numel(ps);
qs = ps .* m ./ (1:m)';
for i = m-1:-1:1
    qs(i) = min(qs(i), qs(i+1));
end
tmp = nan(m,1);
tmp(order) = min(qs, 1);
q(valid) = tmp;
end
