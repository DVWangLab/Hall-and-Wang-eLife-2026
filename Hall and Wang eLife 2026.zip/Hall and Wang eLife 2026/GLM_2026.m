%Import ripple onset timestamp interval
ripple = ripple_onset_timestamp;
%%  Run the GLM
%%% import all ACC units ****must have same Prefix
units_ACC = {};

% Get variable names starting with prefix 'ACC_unit'
accUnitVariables = who('ACC_unit*');

% Loop through each variable
for i = 1:numel(accUnitVariables)
    % Get the vector data from the base workspace
    vectorData = evalin('base', accUnitVariables{i});
    
    % Add the vector data to the cell array
    units_ACC{end+1} = vectorData;
end

%%% Import CA1 units 
units_CA1={}

% Get variable names starting with prefix 'CA1'
units_CA1UnitVariables = who('CA1*');

% Loop through each variable
for i = 1:numel(units_CA1UnitVariables)
    % Get the vector data from the base workspace
    vectorDataCA1 = evalin('base', units_CA1UnitVariables{i});
    
    % Add the vector data to the cell array
    units_CA1{end+1} = vectorDataCA1;
end

%%% clear varaibles 
clearvars -except units_CA1 units_ACC ripple

%%% Get CA1 neuron #
N_CA1 = size(units_CA1,2); %%%%%%%%%%%%% number of CA1 neurons
for N=1:N_CA1
NN=length(units_CA1{N});
units_CA1{N_CA1+N}=units_CA1{N}(1)+(units_CA1{N}(NN)-units_CA1{N}(1)).*sort(rand(NN,1));
end

%%%%%%%%%% select only SWS data
min1=min(ripple); max1=max(ripple);

units_ACC_SWS={};
for i=1:length(units_ACC)
 k=1;
 for j=1:length(units_ACC{1,i})
  if units_ACC{1,i}(j)>min1-1 & units_ACC{1,i}(j)<max1+1
     units_ACC_SWS{1,i}(k)=units_ACC{1,i}(j); k=k+1;
  elseif units_ACC{1,i}(j)>max1+1  break;
  end
 end
end

units_CA1_SWS={};
for i=1:length(units_CA1)
 k=1;
 for j=1:length(units_CA1{1,i})
  if units_CA1{1,i}(j)>min1-1 & units_CA1{1,i}(j)<max1+1
     units_CA1_SWS{1,i}(k)=units_CA1{1,i}(j); k=k+1;
  elseif units_CA1{1,i}(j)>max1+1  break;
  end
 end
end

%%%%%%%%%% calculate ACC predictor windows relative to ripple onset
for a=1:length(ripple)
 for i=1:length(units_ACC_SWS)
  units_ACC_pre400_200(i,a)=0; units_ACC_pre200_0(i,a)=0; units_ACC_pre600_400(i,a)=0;
  for j=1:length(units_ACC_SWS{1,i})
   if units_ACC_SWS{1,i}(j)-ripple(a)>-0.4 & units_ACC_SWS{1,i}(j)-ripple(a)<-0.2
     units_ACC_pre400_200(i,a)=units_ACC_pre400_200(i,a)+1;
   elseif units_ACC_SWS{1,i}(j)-ripple(a)>-0.2 & units_ACC_SWS{1,i}(j)-ripple(a)<0
     units_ACC_pre200_0(i,a)=units_ACC_pre200_0(i,a)+1;
   elseif units_ACC_SWS{1,i}(j)-ripple(a)>-0.6 & units_ACC_SWS{1,i}(j)-ripple(a)<-0.4
     units_ACC_pre600_400(i,a)=units_ACC_pre600_400(i,a)+1;
   elseif units_ACC_SWS{1,i}(j)-ripple(a)>0.2 break;
   end
  end
 end
end

%%%%%%%%%% calculate CA1 response window, 0-100 ms after ripple onset
for a=1:length(ripple)
 for i=1:length(units_CA1_SWS)
  units_CA1_0_100(i,a)=0; 
  for j=1:length(units_CA1_SWS{1,i})
   if units_CA1_SWS{1,i}(j)-ripple(a)>0 & units_CA1_SWS{1,i}(j)-ripple(a)<0.1
     units_CA1_0_100(i,a)=units_CA1_0_100(i,a)+1;
   elseif units_CA1_SWS{1,i}(j)-ripple(a)>0.1 break;
   end
  end
 end
end

%%%% GLM Analysis
data_pre400_200=[units_CA1_0_100; units_ACC_pre400_200];
data_pre200_0=[units_CA1_0_100; units_ACC_pre200_0];
data_pre600_400=[units_CA1_0_100; units_ACC_pre600_400];
a = size(data_pre400_200,2); 

%%%%%% running 500 times

for m=1:500  

k = randperm(a);
data_pre400_200_train = data_pre400_200(:, k(1:round(a/2)));
data_pre400_200_test = data_pre400_200(:, k(round(a/2)+1:end));
data_pre200_0_train = data_pre200_0(:, k(1:round(a/2)));
data_pre200_0_test = data_pre200_0(:, k(round(a/2)+1:end));
data_pre600_400_train = data_pre600_400(:, k(1:round(a/2)));
data_pre600_400_test = data_pre600_400(:, k(round(a/2)+1:end));

b = length(units_CA1_0_100(:,1));
for i=1:b  
  Xpre400_200_train = data_pre400_200_train(b+1:end,:);
  Xpre200_0_train = data_pre200_0_train(b+1:end,:);
  Xpre600_400_train = data_pre600_400_train(b+1:end,:);
  Y_train = data_pre600_400_train(i,:); 

  GLM_pre400_200 = glmfit(Xpre400_200_train',Y_train','poisson');
  GLM_pre200_0 = glmfit(Xpre200_0_train',Y_train','poisson');
  GLM_pre600_400 = glmfit(Xpre600_400_train',Y_train','poisson');

  Xpre400_200_test = data_pre400_200_test(b+1:end,:);
  Xpre200_0_test = data_pre200_0_test(b+1:end,:);
  Xpre600_400_test = data_pre600_400_test(b+1:end,:);
  Y_test(:,i) = data_pre600_400_test(i,:)'; 

  ypred_pre400_200(:,i) = glmval(GLM_pre400_200,Xpre400_200_test','log');
  ypred_pre200_0(:,i) = glmval(GLM_pre200_0,Xpre200_0_test','log');
  ypred_pre600_400(:,i) = glmval(GLM_pre600_400,Xpre600_400_test','log');

  Corr_pre400_200(i,m) = corr(ypred_pre400_200(:,i),Y_test(:,i));
  Corr_pre200_0(i,m) = corr(ypred_pre200_0(:,i),Y_test(:,i));
  Corr_pre600_400(i,m) = corr(ypred_pre600_400(:,i),Y_test(:,i));
end
end

%%%%%% Figure plot
figure, plot(Corr_pre400_200), hold on, plot(mean(Corr_pre400_200'),'linewidth',5,'color','k'), ylim([-0.1 0.6])
figure, plot(Corr_pre200_0), hold on, plot(mean(Corr_pre200_0'),'linewidth',5,'color','k'), ylim([-0.1 0.6])
figure, plot(Corr_pre600_400), hold on, plot(mean(Corr_pre600_400'),'linewidth',5,'color','k'), ylim([-0.1 0.6])

%%%%%%%%% Generate shuffled data for Prediction Gain, -200 to 0 ms
ypred_pre200_0_shuffled = ypred_pre200_0(randperm(size(ypred_pre200_0, 1)),:);

%%%%%%% Prediction Gain Value, -200 to 0 ms
for N=1:size(units_CA1,2)
 PE(:,N)=abs(ypred_pre200_0(:,N)-Y_test(:,N));
 PE_shuffled(:,N)=abs(ypred_pre200_0_shuffled(:,N)-Y_test(:,N));
 Prediction_gain_pre200_0(N) = mean(PE_shuffled(:,N))/mean(PE(:,N));
end
figure, bar(Prediction_gain_pre200_0), ylim([0.95 1.3])

%% Getting Prediction Gain for other time windows

%%%% Generating shuffled data for -400 to -200 ms
ypred_pre400_200_shuffled = ypred_pre400_200(randperm(size(ypred_pre400_200, 1)),:);

%%%% Generating shuffled data for -600 to -400 ms
ypred_pre600_400_shuffled = ypred_pre600_400(randperm(size(ypred_pre600_400, 1)),:);

%%%%% Prediction Gain Value, -600 to -400 ms
for N=1:size(units_CA1,2)
 PE(:,N)=abs(ypred_pre600_400(:,N)-Y_test(:,N));
 PE_shuffled(:,N)=abs(ypred_pre600_400_shuffled(:,N)-Y_test(:,N));
 Prediction_gain_pre600_400(N) = mean(PE_shuffled(:,N))/mean(PE(:,N));
end
figure, bar(Prediction_gain_pre600_400), ylim([0.95 1.3])

%%%%% Prediction Gain Value, -400 to -200 ms
for N=1:size(units_CA1,2)
 PE(:,N)=abs(ypred_pre400_200(:,N)-Y_test(:,N));
 PE_shuffled(:,N)=abs(ypred_pre400_200_shuffled(:,N)-Y_test(:,N));
 Prediction_gain_pre400_200(N) = mean(PE_shuffled(:,N))/mean(PE(:,N));
end
figure, bar(Prediction_gain_pre400_200), ylim([0.95 1.3])

%% Switching formats
PG = Prediction_gain_pre200_0';
PG4 = Prediction_gain_pre400_200';
PG6 = Prediction_gain_pre600_400';