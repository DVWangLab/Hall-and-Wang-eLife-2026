# Publication Analysis Code Templates

These scripts are generalized templates distilled from the analysis code used for Hall & Wang 2026 manuscript: A cortical–hippocampal communication undergoes rebalancing after new learning. 
Each template expects already-loaded MATLAB tables or structs with generic variable names such as `Data`, `SpikeTable`, `UnitTable`, `CurveTable`, `Group`, and `AnimalID`.

## Files

- `template_sta_full_lag_baseline_subtracted.m`
  - General ACC-triggered CA1 STA lag-curve analysis.
  - Computes baseline-subtracted STA curves and full-lag Post-minus-Pre statistics.
  - Omits the scalar STA response metric analysis.

- `template_pg_category_permutation_test.m`
  - General prediction-gain category preservation / turnover analysis.
  - Assigns neurons to Bottom25, Middle50, and Top25 groups in Pre and Post.
  - Computes observed transition matrices and permutation-based chance tests.

- `template_autocorrelogram_by_group.m`
  - General autocorrelogram analysis for spike trains grouped by neuron class.
  - Computes per-neuron autocorrelograms and group mean +/- SEM curves.

- `opto_population_response_heatmaps/template_optostim_4x_population_response_heatmaps.m`
  - General 4X optostimulation population response, heatmap, and sublayer-statistics analysis.
  - Computes z-scored peri-stimulus traces, heatmaps, mean +/- SEM population traces, signed-rank window tests, CA1sup versus CA1deep ranksum tests, and the mixed-effects model used for the population-response analysis.

## Design
