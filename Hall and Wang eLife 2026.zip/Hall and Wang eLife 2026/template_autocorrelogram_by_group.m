function Results = template_autocorrelogram_by_group(SpikeTable, UnitTable, params)
% TEMPLATE_AUTOCORRELOGRAM_BY_GROUP
%
% Generalized autocorrelogram analysis for grouped spike trains.
%
% Required SpikeTable columns:
%   UnitID
%   SpikeTime   spike timestamps in seconds
%
% Required UnitTable columns:
%   UnitID
%   Group       neuron class/group label, e.g. "Group1", "Group2"
%
% Optional UnitTable columns:
%   AnimalID
%   Session
%
% Required params fields:
%   maxLagSec   e.g. 0.05 for +/-50 ms
%   binSizeSec  e.g. 0.001 for 1 ms bins
%
% Output:
%   Results.UnitCurves
%   Results.GroupSummary

arguments
    SpikeTable table
    UnitTable table
    params.maxLagSec double = 0.05
    params.binSizeSec double = 0.001
end

edges = -params.maxLagSec:params.binSizeSec:params.maxLagSec;
centers = edges(1:end-1) + params.binSizeSec/2;
unitRows = cell(0, 5);

for u = 1:height(UnitTable)
    unitID = string(UnitTable.UnitID(u));
    groupName = string(UnitTable.Group(u));
    spikeTimes = sort(SpikeTable.SpikeTime(string(SpikeTable.UnitID) == unitID));
    acg = autocorrelogram(spikeTimes, edges, params.maxLagSec, params.binSizeSec);
    for b = 1:numel(centers)
        unitRows(end+1,:) = {unitID, groupName, centers(b), acg(b), numel(spikeTimes)}; %#ok<AGROW>
    end
end

UnitCurves = cell2table(unitRows, 'VariableNames', {'UnitID','Group','LagSec','ACG_Hz','NSpikes'});
GroupSummary = summarizeGroups(UnitCurves);

Results = struct();
Results.UnitCurves = UnitCurves;
Results.GroupSummary = GroupSummary;
end

function acg = autocorrelogram(spikeTimes, edges, maxLagSec, binSizeSec)
nBins = numel(edges) - 1;
acg = zeros(1, nBins);
spikeTimes = sort(spikeTimes(:));
nSpikes = numel(spikeTimes);
if nSpikes < 2
    return
end

for i = 1:nSpikes
    j = i + 1;
    while j <= nSpikes
        dt = spikeTimes(j) - spikeTimes(i);
        if dt > maxLagSec
            break
        end
        posBin = floor((dt - edges(1)) / binSizeSec) + 1;
        negBin = floor((-dt - edges(1)) / binSizeSec) + 1;
        if posBin >= 1 && posBin <= nBins
            acg(posBin) = acg(posBin) + 1;
        end
        if negBin >= 1 && negBin <= nBins
            acg(negBin) = acg(negBin) + 1;
        end
        j = j + 1;
    end
end

zeroMask = abs(edges(1:end-1) + binSizeSec/2) < (binSizeSec/2);
acg(zeroMask) = 0;

% Units: coincidence count per trigger spike per second.
acg = acg ./ (nSpikes * binSizeSec);
end

function S = summarizeGroups(UnitCurves)
[G, group, lag] = findgroups(string(UnitCurves.Group), UnitCurves.LagSec);
n = splitapply(@numel, UnitCurves.ACG_Hz, G);
mu = splitapply(@mean, UnitCurves.ACG_Hz, G);
sd = splitapply(@std, UnitCurves.ACG_Hz, G);
S = table(group, lag, n, mu, sd ./ sqrt(n), ...
    'VariableNames', {'Group','LagSec','NUnits','MeanACG_Hz','SEMACG_Hz'});
end
