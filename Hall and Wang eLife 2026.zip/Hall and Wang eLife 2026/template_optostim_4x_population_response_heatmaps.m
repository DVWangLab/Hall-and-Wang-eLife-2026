function results = template_optostim_4x_population_response_heatmaps(UnitTable, SpikeTable, StimTable, EpochTable, outDir, varargin)
% TEMPLATE_OPTOSTIM_4X_POPULATION_RESPONSE_HEATMAPS
%
% Publication-friendly template for 4X optostimulation population traces,
% heatmaps, and window-based statistics.
%
% Required input tables:
%   UnitTable:  AnimalID, Session, UnitID, SublayerLabel
%   SpikeTable: AnimalID, Session, UnitID, SpikeTime
%   StimTable:  AnimalID, Session, StimID, StimType, OnsetTime
%   EpochTable: AnimalID, Session, State, StartTime, EndTime
%
% Example:
%   results = template_optostim_4x_population_response_heatmaps( ...
%       UnitTable, SpikeTable, StimTable, EpochTable, "results/opto_4x");
%
% Core analysis:
%   1. Keep 4X stimulation events.
%   2. Assign each stimulation event to SWS or NON_SWS using epoch intervals.
%   3. For each neuron and state, compute peri-stimulus firing traces.
%   4. Smooth traces with a Gaussian kernel.
%   5. Z-score each neuron to its pre-stimulus baseline.
%   6. Export heatmaps, mean +/- SEM population traces, and statistics.
%
% Default model:
%   DeltaZ ~ Window * Sublayer + (1|AnimalID) + (1|UnitKey)

parser = inputParser;
parser.addRequired('UnitTable', @istable);
parser.addRequired('SpikeTable', @istable);
parser.addRequired('StimTable', @istable);
parser.addRequired('EpochTable', @istable);
parser.addRequired('outDir', @(x) ischar(x) || isstring(x));
parser.addParameter('BinSizeSec', 0.02, @(x) isnumeric(x) && isscalar(x) && x > 0);
parser.addParameter('SigmaBins', 3, @(x) isnumeric(x) && isscalar(x) && x > 0);
parser.addParameter('AnalysisWindowSec', [-2 4], @(x) isnumeric(x) && numel(x) == 2 && x(1) < x(2));
parser.addParameter('BaselineWindowSec', [-2 0], @(x) isnumeric(x) && numel(x) == 2 && x(1) < x(2));
parser.addParameter('StateLabels', ["SWS","NON_SWS"], @(x) isstring(x) || iscellstr(x));
parser.addParameter('MinStimCount', 1, @(x) isnumeric(x) && isscalar(x) && x >= 1);
parser.parse(UnitTable, SpikeTable, StimTable, EpochTable, outDir, varargin{:});

outDir = char(parser.Results.outDir);
binSize = parser.Results.BinSizeSec;
sigmaBins = parser.Results.SigmaBins;
analysisWindow = parser.Results.AnalysisWindowSec;
baselineWindow = parser.Results.BaselineWindowSec;
stateLabels = string(parser.Results.StateLabels);
minStimCount = parser.Results.MinStimCount;

ensure_dir(outDir);

UnitTable = standardize_table_strings(UnitTable, ["AnimalID","Session","UnitID","SublayerLabel"]);
SpikeTable = standardize_table_strings(SpikeTable, ["AnimalID","Session","UnitID"]);
StimTable = standardize_table_strings(StimTable, ["AnimalID","Session","StimID","StimType"]);
EpochTable = standardize_table_strings(EpochTable, ["AnimalID","Session","State"]);

StimTable = StimTable(string(StimTable.StimType) == "4X", :);
StimTable.State = assign_stim_states(StimTable, EpochTable);
StimTable = StimTable(ismember(string(StimTable.State), stateLabels), :);

binEdges = analysisWindow(1):binSize:analysisWindow(2);
binCenters = binEdges(1:end-1) + binSize / 2;
kernel = gaussian_kernel(sigmaBins);

results = struct();
results.Parameters = parser.Results;
results.BinCenters = binCenters(:);
results.StimEvents = StimTable;

for s = 1:numel(stateLabels)
    stateName = stateLabels(s);
    stateDir = fullfile(outDir, char(stateName));
    ensure_dir(stateDir);

    stateStim = StimTable(string(StimTable.State) == stateName, :);
    unitSummary = build_unit_summary(UnitTable, SpikeTable, stateStim, binEdges, binCenters, ...
        binSize, kernel, baselineWindow, minStimCount, stateName);

    if isempty(unitSummary)
        warning('No units available for state %s.', stateName);
        continue
    end

    unitTable = struct2table(unitSummary);
    windowStats = run_group_window_stats(unitSummary);
    [sublayerStats, lmeTable, lmeText] = run_sublayer_stats(unitSummary);

    writetable(unitTable, fullfile(stateDir, sprintf('optostim_4x_%s_unit_summary_zscore.csv', lower(stateName))));
    writetable(windowStats, fullfile(stateDir, sprintf('optostim_4x_%s_window_stats_zscore.csv', lower(stateName))));
    writetable(sublayerStats, fullfile(stateDir, sprintf('optostim_4x_%s_sublayer_comparison_zscore.csv', lower(stateName))));
    writetable(lmeTable, fullfile(stateDir, sprintf('optostim_4x_%s_population_window_table_zscore.csv', lower(stateName))));

    make_heatmap(unitSummary, binCenters, @(u) true(numel(u), 1), ...
        sprintf('%s: all neurons', stateName), fullfile(stateDir, sprintf('heatmap_all_neurons_4x_%s_zscore', lower(stateName))));
    make_heatmap(unitSummary, binCenters, @(u) string({u.SublayerLabel})' == "CA1sup", ...
        sprintf('%s: CA1sup', stateName), fullfile(stateDir, sprintf('heatmap_CA1sup_4x_%s_zscore', lower(stateName))));
    make_heatmap(unitSummary, binCenters, @(u) string({u.SublayerLabel})' == "CA1deep", ...
        sprintf('%s: CA1deep', stateName), fullfile(stateDir, sprintf('heatmap_CA1deep_4x_%s_zscore', lower(stateName))));

    make_population_trace(unitSummary, binCenters, ...
        sprintf('4X optostimulation population response (%s)', stateName), ...
        fullfile(stateDir, sprintf('population_traces_4x_%s_zscore', lower(stateName))));

    write_summary(fullfile(stateDir, sprintf('optostim_4x_%s_summary_zscore.txt', lower(stateName))), ...
        unitSummary, windowStats, sublayerStats, lmeText, binSize, sigmaBins, analysisWindow, baselineWindow, stateName);

    results.(char(stateName)).UnitSummary = unitSummary;
    results.(char(stateName)).UnitTable = unitTable;
    results.(char(stateName)).WindowStats = windowStats;
    results.(char(stateName)).SublayerStats = sublayerStats;
    results.(char(stateName)).PopulationWindowTable = lmeTable;
    results.(char(stateName)).LMEText = lmeText;
end

save(fullfile(outDir, 'optostim_4x_population_response_results.mat'), 'results', '-v7.3');
end

function unitSummary = build_unit_summary(UnitTable, SpikeTable, StimTable, binEdges, binCenters, binSize, kernel, baselineWindow, minStimCount, stateName)
unitSummary = struct([]);
baselineMask = binCenters >= baselineWindow(1) & binCenters < baselineWindow(2);
post0_1 = binCenters >= 0 & binCenters < 1;
post1_2 = binCenters >= 1 & binCenters < 2;
post2_3 = binCenters >= 2 & binCenters < 3;
post3_4 = binCenters >= 3 & binCenters < 4;
post0_3 = binCenters >= 0 & binCenters < 3;

for u = 1:height(UnitTable)
    animalID = string(UnitTable.AnimalID(u));
    session = string(UnitTable.Session(u));
    unitID = string(UnitTable.UnitID(u));
    stimIdx = string(StimTable.AnimalID) == animalID & string(StimTable.Session) == session;
    stimTimes = StimTable.OnsetTime(stimIdx);
    stimTimes = stimTimes(isfinite(stimTimes));
    if numel(stimTimes) < minStimCount
        continue
    end

    spikeIdx = string(SpikeTable.AnimalID) == animalID & string(SpikeTable.Session) == session & ...
        string(SpikeTable.UnitID) == unitID;
    spikeTimes = SpikeTable.SpikeTime(spikeIdx);
    spikeTimes = spikeTimes(isfinite(spikeTimes));

    counts = zeros(numel(stimTimes), numel(binCenters));
    for k = 1:numel(stimTimes)
        rel = spikeTimes - stimTimes(k);
        rel = rel(rel >= binEdges(1) & rel < binEdges(end));
        if ~isempty(rel)
            counts(k,:) = histcounts(rel, binEdges);
        end
    end

    meanTraceHz = mean(counts, 1) ./ binSize;
    smoothTraceHz = smooth_with_edge_padding(meanTraceHz, kernel);
    baselineMeanHz = mean(smoothTraceHz(baselineMask), 'omitnan');
    baselineStdHz = std(smoothTraceHz(baselineMask), 0, 2, 'omitnan');
    if isempty(baselineStdHz) || isnan(baselineStdHz) || baselineStdHz == 0
        baselineStdHz = NaN;
    end
    zTrace = (smoothTraceHz - baselineMeanHz) ./ baselineStdHz;

    row = struct();
    row.State = stateName;
    row.AnimalID = animalID;
    row.Session = session;
    row.UnitID = unitID;
    row.SublayerLabel = string(UnitTable.SublayerLabel(u));
    row.UnitKey = animalID + "|" + session + "|" + unitID;
    row.StimCount = numel(stimTimes);
    row.PreMeanHz = baselineMeanHz;
    row.PreStdHz = baselineStdHz;
    row.Post0_1Z = mean(zTrace(post0_1), 'omitnan');
    row.Post1_2Z = mean(zTrace(post1_2), 'omitnan');
    row.Post2_3Z = mean(zTrace(post2_3), 'omitnan');
    row.Post3_4Z = mean(zTrace(post3_4), 'omitnan');
    row.Post0_3Z = mean(zTrace(post0_3), 'omitnan');
    row.MeanTraceHz = meanTraceHz;
    row.SmoothTraceHz = smoothTraceHz;
    row.ZTrace = zTrace;
    unitSummary(end+1,1) = row; %#ok<AGROW>
end
end

function statsTable = run_group_window_stats(unitSummary)
groups = {
    "All neurons", @(u) true(numel(u), 1);
    "CA1sup", @(u) string({u.SublayerLabel})' == "CA1sup";
    "CA1deep", @(u) string({u.SublayerLabel})' == "CA1deep";
    };
fields = ["Post0_1Z","Post1_2Z","Post2_3Z","Post3_4Z","Post0_3Z"];
labels = ["0-1 s","1-2 s","2-3 s","3-4 s","0-3 s"];
rows = table();
for g = 1:size(groups, 1)
    subset = unitSummary(groups{g,2}(unitSummary));
    pVals = nan(numel(fields),1);
    nVals = nan(numel(fields),1);
    medVals = nan(numel(fields),1);
    for w = 1:numel(fields)
        z = [subset.(fields(w))]';
        z = z(isfinite(z));
        nVals(w) = numel(z);
        medVals(w) = median(z, 'omitnan');
        if ~isempty(z)
            pVals(w) = signrank(z, 0, 'method', 'approximate');
        end
    end
    qVals = fdr_bh(pVals);
    rows = safe_vertcat(rows, table(repmat(groups{g,1}, numel(fields), 1), labels', nVals, pVals, qVals, medVals, ...
        'VariableNames', {'Group','Window','N','PValue','QValue','MedianZ'}));
end
statsTable = rows;
end

function [statsTable, lmeTable, lmeText] = run_sublayer_stats(unitSummary)
fields = ["Post0_1Z","Post1_2Z","Post2_3Z","Post3_4Z","Post0_3Z"];
labels = ["0-1 s","1-2 s","2-3 s","3-4 s","0-3 s"];
sup = unitSummary(string({unitSummary.SublayerLabel})' == "CA1sup");
deep = unitSummary(string({unitSummary.SublayerLabel})' == "CA1deep");

rows = table();
for w = 1:numel(fields)
    x = [sup.(fields(w))]'; x = x(isfinite(x));
    y = [deep.(fields(w))]'; y = y(isfinite(y));
    p = NaN;
    if ~isempty(x) && ~isempty(y)
        p = ranksum(x, y);
    end
    rows = safe_vertcat(rows, table(labels(w), numel(x), numel(y), median(x,'omitnan'), median(y,'omitnan'), p, ...
        'VariableNames', {'Window','N_CA1sup','N_CA1deep','MedianZ_CA1sup','MedianZ_CA1deep','PValue'}));
end
rows.QValue = fdr_bh(rows.PValue);
statsTable = rows;

keep = string({unitSummary.SublayerLabel})' == "CA1sup" | string({unitSummary.SublayerLabel})' == "CA1deep";
subset = unitSummary(keep);
if isempty(subset)
    lmeTable = table();
    lmeText = 'No CA1sup/CA1deep units available.';
    return
end

lmeTable = table();
for u = 1:numel(subset)
    for w = 1:numel(fields)
        lmeTable = safe_vertcat(lmeTable, table( ...
            categorical(string(subset(u).AnimalID)), categorical(string(subset(u).UnitKey)), ...
            categorical(string(subset(u).SublayerLabel)), categorical(labels(w)), subset(u).(fields(w)), ...
            'VariableNames', {'AnimalID','UnitKey','Sublayer','Window','DeltaZ'}));
    end
end
lmeTable = lmeTable(isfinite(lmeTable.DeltaZ), :);
try
    mdl = fitlme(lmeTable, 'DeltaZ ~ Window * Sublayer + (1|AnimalID) + (1|UnitKey)');
    lmeText = evalc('disp(mdl)');
catch ME
    lmeText = sprintf('fitlme failed: %s', ME.message);
end
end

function make_heatmap(unitSummary, binCenters, maskFn, titleText, outBase)
subset = unitSummary(maskFn(unitSummary));
subset = subset(arrayfun(@(u) any(isfinite(u.ZTrace)) && isfinite(u.Post0_3Z), subset));
if isempty(subset), return, end
Z = vertcat(subset.ZTrace);
[~, order] = sort([subset.Post0_3Z]', 'descend');
Z = Z(order,:);
fig = figure('Color','w', 'Position',[100 100 900 650], 'Renderer','painters');
imagesc(binCenters, 1:size(Z,1), Z);
axis tight;
set(gca, 'TickDir','out', 'Box','off');
xlabel('Time from 4X stimulation onset (s)');
ylabel('Neuron');
title(titleText);
colorbar;
caxis([-3 3]);
save_all(fig, outBase);
close(fig);
end

function make_population_trace(unitSummary, binCenters, titleText, outBase)
groups = ["All neurons","CA1sup","CA1deep"];
colors = [0.2 0.2 0.2; 0.1 0.32 0.78; 0.82 0.16 0.16];
fig = figure('Color','w', 'Position',[120 120 760 500], 'Renderer','painters');
ax = axes(fig); hold(ax, 'on');
for g = 1:numel(groups)
    if groups(g) == "All neurons"
        subset = unitSummary;
    else
        subset = unitSummary(string({unitSummary.SublayerLabel})' == groups(g));
    end
    if isempty(subset), continue, end
    Z = vertcat(subset.ZTrace);
    mu = mean(Z, 1, 'omitnan');
    sem = std(Z, 0, 1, 'omitnan') ./ sqrt(size(Z,1));
    fill(ax, [binCenters fliplr(binCenters)], [mu+sem fliplr(mu-sem)], colors(g,:), ...
        'FaceAlpha', 0.16, 'EdgeColor', 'none');
    plot(ax, binCenters, mu, 'Color', colors(g,:), 'LineWidth', 2.2, ...
        'DisplayName', sprintf('%s (n=%d)', groups(g), size(Z,1)));
end
plot(ax, [0 0], ylim(ax), 'k--', 'HandleVisibility','off');
xlabel(ax, 'Time from 4X stimulation onset (s)');
ylabel(ax, 'Z-scored firing rate');
title(ax, titleText);
legend(ax, 'Location','best', 'Box','off');
set(ax, 'TickDir','out', 'Box','off');
save_all(fig, outBase);
close(fig);
end

function state = assign_stim_states(StimTable, EpochTable)
state = strings(height(StimTable), 1);
for i = 1:height(StimTable)
    idx = string(EpochTable.AnimalID) == string(StimTable.AnimalID(i)) & ...
        string(EpochTable.Session) == string(StimTable.Session(i)) & ...
        StimTable.OnsetTime(i) >= EpochTable.StartTime & ...
        StimTable.OnsetTime(i) <= EpochTable.EndTime;
    match = EpochTable(idx, :);
    if ~isempty(match)
        state(i) = string(match.State(1));
    else
        state(i) = "UNASSIGNED";
    end
end
end

function kernel = gaussian_kernel(sigmaBins)
radius = ceil(4 * sigmaBins);
x = -radius:radius;
kernel = exp(-(x.^2) ./ (2 * sigmaBins^2));
kernel = kernel ./ sum(kernel);
end

function y = smooth_with_edge_padding(x, kernel)
pad = floor(numel(kernel) / 2);
xPad = [repmat(x(1), 1, pad), x, repmat(x(end), 1, pad)];
yPad = conv(xPad, kernel, 'same');
y = yPad((pad+1):(pad+numel(x)));
end

function T = standardize_table_strings(T, names)
for i = 1:numel(names)
    if ismember(names(i), string(T.Properties.VariableNames))
        T.(names(i)) = string(T.(names(i)));
    end
end
end

function out = safe_vertcat(a, b)
if isempty(a), out = b; return, end
if isempty(b), out = a; return, end
out = [a; b];
end

function q = fdr_bh(p)
q = nan(size(p));
valid = isfinite(p);
if ~any(valid), return, end
pv = p(valid);
[ps, order] = sort(pv);
m = numel(ps);
qs = ps .* m ./ (1:m)';
qs = min(1, flipud(cummin(flipud(qs))));
qv = nan(size(pv));
qv(order) = qs;
q(valid) = qv;
end

function save_all(fig, outBase)
savefig(fig, [outBase '.fig']);
print(fig, [outBase '.svg'], '-dsvg', '-painters');
print(fig, [outBase '.png'], '-dpng', '-r300');
end

function ensure_dir(d)
if exist(d, 'dir') ~= 7
    mkdir(d);
end
end

function write_summary(pathName, unitSummary, windowStats, sublayerStats, lmeText, binSize, sigmaBins, analysisWindow, baselineWindow, stateName)
fid = fopen(pathName, 'w');
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid, '4X optostimulation z-scored population response analysis\n');
fprintf(fid, 'State: %s\n', stateName);
fprintf(fid, 'Analysis window: %.3f to %.3f s\n', analysisWindow(1), analysisWindow(2));
fprintf(fid, 'Baseline window: %.3f to %.3f s\n', baselineWindow(1), baselineWindow(2));
fprintf(fid, 'Bin size: %.3f s\n', binSize);
fprintf(fid, 'Gaussian smoothing sigma: %.3f bins\n', sigmaBins);
fprintf(fid, 'Units analyzed: %d\n\n', numel(unitSummary));

fprintf(fid, 'Window tests: signed-rank test against zero z-scored response, FDR-corrected across windows within group.\n');
for i = 1:height(windowStats)
    fprintf(fid, '%s %s: n=%d, median z=%.4f, p=%.4g, q=%.4g\n', ...
        windowStats.Group(i), windowStats.Window(i), windowStats.N(i), ...
        windowStats.MedianZ(i), windowStats.PValue(i), windowStats.QValue(i));
end

fprintf(fid, '\nCA1sup versus CA1deep window comparisons: ranksum test, FDR-corrected across windows.\n');
for i = 1:height(sublayerStats)
    fprintf(fid, '%s: CA1sup n=%d median=%.4f; CA1deep n=%d median=%.4f; p=%.4g; q=%.4g\n', ...
        sublayerStats.Window(i), sublayerStats.N_CA1sup(i), sublayerStats.MedianZ_CA1sup(i), ...
        sublayerStats.N_CA1deep(i), sublayerStats.MedianZ_CA1deep(i), ...
        sublayerStats.PValue(i), sublayerStats.QValue(i));
end

fprintf(fid, '\nMixed-effects model:\n');
fprintf(fid, 'DeltaZ ~ Window * Sublayer + (1|AnimalID) + (1|UnitKey)\n\n');
fprintf(fid, '%s\n', lmeText);
end
